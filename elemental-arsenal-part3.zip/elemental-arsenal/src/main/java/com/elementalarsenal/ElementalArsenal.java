package com.elementalarsenal;

import java.util.function.Predicate;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectionContext;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ConstantValue;

public class ElementalArsenal implements ModInitializer {
	public static final String MOD_ID = "elementalarsenal";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModItems.init();
		ModBlocks.init();
		ModEntities.init();
		FireHallTrigger.init();
		ArsenalEvents.init();
		addOreGeneration();
		boostHeavyCore();
	}

	/** Crystal ores: fire in the Nether, ice / wind / earth in the Overworld (details in data/.../worldgen). */
	private static void addOreGeneration() {
		addOre(BiomeSelectors.foundInTheNether(), "fire_ore");
		addOre(BiomeSelectors.foundInOverworld(), "ice_ore");
		addOre(BiomeSelectors.foundInOverworld(), "wind_ore");
		addOre(BiomeSelectors.foundInOverworld(), "earth_ore");
	}

	private static void addOre(Predicate<BiomeSelectionContext> biomes, String name) {
		BiomeModifications.addFeature(biomes, GenerationStep.Decoration.UNDERGROUND_ORES,
				ResourceKey.create(Registries.PLACED_FEATURE, id(name)));
	}

	/**
	 * Heavy Core (needed to craft the Mace) drops from the Ominous Vault "unique" loot with ~7.5% chance.
	 * This adds a small extra chance on top, which makes it about 25% more likely.
	 * Change HEAVY_CORE_BONUS_CHANCE to tune it (0.02 = +2% extra chance on each roll of that loot table).
	 */
	private static final float HEAVY_CORE_BONUS_CHANCE = 0.02F;

	private static final ResourceKey<LootTable> OMINOUS_UNIQUE = ResourceKey.create(Registries.LOOT_TABLE,
			Identifier.withDefaultNamespace("chests/trial_chambers/reward_ominous_unique"));

	private static void boostHeavyCore() {
		LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
			if (OMINOUS_UNIQUE.equals(key)) {
				tableBuilder.withPool(LootPool.lootPool()
						.setRolls(ConstantValue.exactly(1.0F))
						.when(LootItemRandomChanceCondition.randomChance(HEAVY_CORE_BONUS_CHANCE))
						.add(LootItem.lootTableItem(Items.HEAVY_CORE)));
			}
		});
	}
}
