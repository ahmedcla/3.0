package com.elementalarsenal.client;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class FireMonsterRenderState extends LivingEntityRenderState {
	public static final int STATE_NOVA = 1;
	public static final int STATE_LANCE = 2;
	public static final int STATE_ERUPTION = 3;

	/** Which special attack is being charged (0 = none); synced from the entity. */
	public int attackState;
	/** Melee swing progress, 0..1. */
	public float attackAnim;
}
