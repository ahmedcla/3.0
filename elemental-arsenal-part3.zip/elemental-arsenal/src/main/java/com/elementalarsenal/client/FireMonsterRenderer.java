package com.elementalarsenal.client;

import com.elementalarsenal.ElementalArsenal;
import com.elementalarsenal.FireMonster;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class FireMonsterRenderer extends MobRenderer<FireMonster, FireMonsterRenderState, FireMonsterModel> {
	private static final Identifier TEXTURE = ElementalArsenal.id("textures/entity/fire_monster.png");

	public FireMonsterRenderer(EntityRendererProvider.Context context) {
		super(context, new FireMonsterModel(FireMonsterModel.createBodyLayer().bakeRoot()), 1.6F);
	}

	@Override
	public FireMonsterRenderState createRenderState() {
		return new FireMonsterRenderState();
	}

	@Override
	public Identifier getTextureLocation(FireMonsterRenderState state) {
		return TEXTURE;
	}

	@Override
	public void extractRenderState(FireMonster entity, FireMonsterRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.attackState = entity.getAttackState();
		state.attackAnim = entity.getAttackAnim(partialTick);
	}
}
