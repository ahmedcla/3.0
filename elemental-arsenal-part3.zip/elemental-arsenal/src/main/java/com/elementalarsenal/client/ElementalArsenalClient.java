package com.elementalarsenal.client;

import com.elementalarsenal.ModEntities;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class ElementalArsenalClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		EntityRendererRegistry.register(ModEntities.FIRE_MONSTER, FireMonsterRenderer::new);
	}
}
