package com.elementalarsenal;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public final class ModEntities {
	private ModEntities() {
	}

	public static final ResourceKey<EntityType<?>> FIRE_MONSTER_KEY =
			ResourceKey.create(Registries.ENTITY_TYPE, ElementalArsenal.id("fire_monster"));

	public static final EntityType<FireMonster> FIRE_MONSTER = Registry.register(
			BuiltInRegistries.ENTITY_TYPE,
			FIRE_MONSTER_KEY,
			EntityType.Builder.of(FireMonster::new, MobCategory.MONSTER)
					.sized(2.2F, 3.6F)
					.fireImmune()
					.clientTrackingRange(10)
					.build(FIRE_MONSTER_KEY));

	public static void init() {
		FabricDefaultAttributeRegistry.register(FIRE_MONSTER, FireMonster.createAttributes());
	}
}
