package com.elementalarsenal;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.Difficulty;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

/**
 * Wakes the Inferno Colossus when a player walks into the Infernal Hall.
 * <p>
 * The hall's centre has a 3x3 plate of {@link ModBlocks#INFERNO_SEAL}. Once a second every player in the Nether
 * is checked: if a seal block is within {@link #RADIUS} blocks (about the length of the hall) the seal burns away
 * and the monster rises from its place. The seal is removed, so each hall awakens its boss exactly once.
 */
public final class FireHallTrigger {
	private FireHallTrigger() {
	}

	/** Horizontal trigger distance from the seal (the player is then inside the hall, past the gate). */
	private static final int RADIUS = 22;
	/** Vertical trigger distance. */
	private static final int HEIGHT = 8;

	public static void init() {
		ServerTickEvents.END_SERVER_TICK.register(FireHallTrigger::onServerTick);
	}

	private static void onServerTick(MinecraftServer server) {
		if (server.getTickCount() % 20 != 0) {
			return;
		}
		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			if (player.isSpectator() || !player.isAlive()) {
				continue;
			}
			if (!(player.level() instanceof ServerLevel level) || level.dimension() != Level.NETHER) {
				continue;
			}
			// The monster despawns at once on Peaceful, so the seal stays intact there
			if (level.getDifficulty() == Difficulty.PEACEFUL) {
				continue;
			}
			BlockPos seal = findSeal(level, player.blockPosition());
			if (seal != null) {
				awaken(level, seal, player);
			}
		}
	}

	/**
	 * The seal is a 3x3 plate, so sampling every 3rd block in x and z always hits it.
	 * That keeps this check cheap enough to run for every player each second.
	 */
	private static BlockPos findSeal(ServerLevel level, BlockPos center) {
		BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
		for (int x = center.getX() - RADIUS; x <= center.getX() + RADIUS; x += 3) {
			for (int z = center.getZ() - RADIUS; z <= center.getZ() + RADIUS; z += 3) {
				int dx = x - center.getX();
				int dz = z - center.getZ();
				if (dx * dx + dz * dz > RADIUS * RADIUS) {
					continue;
				}
				for (int y = center.getY() - HEIGHT; y <= center.getY() + HEIGHT; y++) {
					pos.set(x, y, z);
					if (level.hasChunkAt(pos) && level.getBlockState(pos).is(ModBlocks.INFERNO_SEAL)) {
						return pos.immutable();
					}
				}
			}
		}
		return null;
	}

	private static void awaken(ServerLevel level, BlockPos found, ServerPlayer player) {
		// Burn away the whole plate and find its centre
		double sumX = 0;
		double sumZ = 0;
		int count = 0;
		int y = found.getY();
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				BlockPos p = found.offset(dx, 0, dz);
				if (level.getBlockState(p).is(ModBlocks.INFERNO_SEAL)) {
					level.setBlock(p, Blocks.CRYING_OBSIDIAN.defaultBlockState(), 3);
					sumX += p.getX() + 0.5D;
					sumZ += p.getZ() + 0.5D;
					count++;
				}
			}
		}
		if (count == 0) {
			return;
		}
		double x = sumX / count;
		double z = sumZ / count;

		FireMonster monster = new FireMonster(ModEntities.FIRE_MONSTER, level);
		monster.setPos(x, y + 1.0D, z);
		monster.setYRot((float) (Math.toDegrees(Math.atan2(player.getZ() - z, player.getX() - x)) - 90.0D));
		monster.setPersistenceRequired();
		monster.setTarget(player);
		level.addFreshEntity(monster);

		monster.playSound(SoundEvents.WITHER_SPAWN, 3.0F, 0.7F);
		level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1.5D, z, 1, 0, 0, 0, 0);
		level.sendParticles(ParticleTypes.FLAME, x, y + 1.0D, z, 120, 1.5D, 1.5D, 1.5D, 0.12D);
		level.sendParticles(ParticleTypes.LAVA, x, y + 1.5D, z, 40, 1.2D, 0.8D, 1.2D, 0.0D);
		level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y + 1.0D, z, 60, 1.5D, 1.5D, 1.5D, 0.05D);
	}
}
