give @s elementalarsenal:fire_sword
give @s elementalarsenal:fire_helmet
give @s elementalarsenal:fire_chestplate
give @s elementalarsenal:fire_leggings
give @s elementalarsenal:fire_boots
