give @s elementalarsenal:wind_sword
give @s elementalarsenal:wind_helmet
give @s elementalarsenal:wind_chestplate
give @s elementalarsenal:wind_leggings
give @s elementalarsenal:wind_boots
