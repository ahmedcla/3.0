#!/usr/bin/env python3
"""Builds the Infernal Hall structure template (.nbt) for the Elemental Arsenal mod.
Usage: gen_hall.py <out.nbt> [preview_prefix]"""
import gzip, math, random, struct, sys

OUT = sys.argv[1]
PREVIEW = sys.argv[2] if len(sys.argv) > 2 else None
rng = random.Random(20261022)

W, H, D = 41, 40, 62          # template size (x, y, z)
FL = 10                        # floor block layer
CX = 20                        # centre axis
ARENA = (20, 30)               # centre of the boss arena (x, z)
G = {}                         # (x, y, z) -> block string
NBT = {}                       # (x, y, z) -> block entity data

AIR = "minecraft:air"

# ------------------------------------------------------------------ blocks
PBB = "minecraft:polished_blackstone_bricks"
CPBB = "minecraft:cracked_polished_blackstone_bricks"
PB = "minecraft:polished_blackstone"
BS = "minecraft:blackstone"
CHB = "minecraft:chiseled_polished_blackstone"
GILD = "minecraft:gilded_blackstone"
NB = "minecraft:nether_bricks"
RNB = "minecraft:red_nether_bricks"
CNB = "minecraft:cracked_nether_bricks"
CHNB = "minecraft:chiseled_nether_bricks"
CRY = "minecraft:crying_obsidian"
OBS = "minecraft:obsidian"
MAG = "minecraft:magma_block"
SHR = "minecraft:shroomlight"
BASALT = "minecraft:basalt[axis=y]"
PBASALT = "minecraft:polished_basalt[axis=y]"
SBASALT = "minecraft:smooth_basalt"
LAVA = "minecraft:lava[level=0]"
BARS = "minecraft:iron_bars"
FENCE = "minecraft:nether_brick_fence"
PBB_WALL = "minecraft:polished_blackstone_brick_wall"
SEAL = "elementalarsenal:inferno_seal"
LAVA_CAULDRON = "minecraft:lava_cauldron"

def stairs(kind, facing, half="bottom"):
    return f"minecraft:{kind}_stairs[facing={facing},half={half},shape=straight,waterlogged=false]"

def slab(kind, typ="bottom"):
    return f"minecraft:{kind}_slab[type={typ},waterlogged=false]"

def lantern(hanging, soul=False):
    return f"minecraft:{'soul_' if soul else ''}lantern[hanging={'true' if hanging else 'false'},waterlogged=false]"

def pick(*weighted):
    total = sum(w for _, w in weighted)
    def f():
        r = rng.uniform(0, total)
        for b, w in weighted:
            r -= w
            if r <= 0:
                return b
        return weighted[-1][0]
    return f

WALL_MAT = pick((PBB, 62), (CPBB, 12), (BS, 14), (PB, 12))
FOUND_MAT = pick((BS, 55), (BASALT, 20), (PB, 10), (SBASALT, 10), (MAG, 5))
FLOOR_MAT = pick((PBB, 70), (PB, 20), (CPBB, 10))
ROOF_MAT = pick((NB, 60), (RNB, 25), (CNB, 15))

def put(x, y, z, b):
    if 0 <= x < W and 0 <= y < H and 0 <= z < D:
        G[(x, y, z)] = b() if callable(b) else b

def fill(x0, y0, z0, x1, y1, z1, b):
    for x in range(min(x0, x1), max(x0, x1) + 1):
        for y in range(min(y0, y1), max(y0, y1) + 1):
            for z in range(min(z0, z1), max(z0, z1) + 1):
                put(x, y, z, b)

def carve(x0, y0, z0, x1, y1, z1):
    fill(x0, y0, z0, x1, y1, z1, AIR)

def ring_rect(x0, z0, x1, z1, y, b):
    for x in range(x0, x1 + 1):
        put(x, y, z0, b); put(x, y, z1, b)
    for z in range(z0, z1 + 1):
        put(x0, y, z, b); put(x1, y, z, b)

# ================================================================== 1. foundation
for y in range(0, 10):
    inset = (9 - y)
    fill(1 + inset, y, 1 + inset, W - 2 - inset, y, D - 2 - inset, FOUND_MAT)
# decorative band below the floor edge
for x in range(1, W - 1):
    put(x, 9, 1, CHB); put(x, 9, D - 2, CHB)
for z in range(1, D - 1):
    put(1, 9, z, CHB); put(W - 2, 9, z, CHB)

# ================================================================== 2. floor
fill(1, FL, 1, W - 2, FL, D - 2, FLOOR_MAT)
# runway (red nether bricks with polished borders) from the gate to the dais
for z in range(1, 47):
    for x in range(18, 23):
        put(x, FL, z, RNB)
    put(17, FL, z, CHNB if z % 4 == 0 else PB)
    put(23, FL, z, CHNB if z % 4 == 0 else PB)
for z in range(2, 47, 8):
    put(17, FL, z, GILD); put(23, FL, z, GILD)

# ================================================================== 3. shells
# main hall + gatehouse + treasury as solid volumes, carved afterwards
fill(3, 11, 9, 37, 27, 48, WALL_MAT)        # hall + gate wall + back wall + roof slab
fill(3, 11, 47, 37, 21, 60, WALL_MAT)       # treasury block
carve(5, 11, 12, 35, 25, 46)                # hall interior
carve(5, 11, 49, 35, 18, 58)                # treasury interior

# plinth ledge around the hall (outer walls start one block in)
for z in range(9, 61):
    put(2, 11, z, stairs("polished_blackstone_brick", "east"))
    put(38, 11, z, stairs("polished_blackstone_brick", "west"))

# ================================================================== 4. gate
# arch opening
carve(16, 11, 9, 24, 19, 11)
carve(17, 20, 9, 23, 20, 11)
carve(18, 21, 9, 22, 21, 11)
# arch trim
for x in range(15, 26):
    put(x, 22, 9, CHB if x not in (CX,) else GILD)
for y in range(11, 22):
    put(15, y, 9, CHB if y % 3 == 0 else PBB)
    put(25, y, 9, CHB if y % 3 == 0 else PBB)
for x, y in ((16, 20), (17, 21), (24, 20), (23, 21)):
    put(x, y, 9, CRY)
# raised portcullis
for x in range(16, 25):
    put(x, 19, 10, BARS)
for x in range(17, 24):
    put(x, 20, 10, BARS)
for x in range(18, 23):
    put(x, 21, 10, BARS)

# gate towers (protrude to the front)
def tower(x0, z0, size, y_top):
    x1, z1 = x0 + size - 1, z0 + size - 1
    fill(x0, 11, z0, x1, y_top, z1, WALL_MAT)
    # corner columns of chiseled blackstone
    for (x, z) in ((x0, z0), (x1, z0), (x0, z1), (x1, z1)):
        fill(x, 11, z, x, y_top, z, CHB)
    # window slits with glow
    mx, mz = (x0 + x1) // 2, (z0 + z1) // 2
    for y in (16, 17, 18):
        put(mx, y, z0, BARS); put(mx, y, z1, BARS)
        put(x0, y, mz, BARS); put(x1, y, mz, BARS)
    put(mx, 17, z0, SHR)
    for y in range(13, y_top, 5):
        ring_rect(x0, z0, x1, z1, y, CRY if y == 13 else CHNB)
    # overhanging crown
    fill(x0 - 1, y_top + 1, z0 - 1, x1 + 1, y_top + 1, z1 + 1, PBB)
    ring_rect(x0 - 1, z0 - 1, x1 + 1, z1 + 1, y_top + 2, PBB_WALL)
    fill(x0, y_top + 2, z0, x1, y_top + 2, z1, AIR)
    # fire bowl
    put(mx, y_top + 2, mz, LAVA_CAULDRON)
    put(mx + 1, y_top + 2, mz, LAVA_CAULDRON) if size >= 6 else None
    for (x, z) in ((x0 - 1, z0 - 1), (x1 + 1, z0 - 1), (x0 - 1, z1 + 1), (x1 + 1, z1 + 1)):
        put(x, y_top + 3, z, lantern(False))

tower(8, 5, 6, 31)
tower(27, 5, 6, 31)

# ================================================================== 5. hall interior
# --- hanging lantern rows (iron bars as hangers) and ceiling light grid
for z in (14, 19, 24, 36, 41):
    for x in (15, 25):
        fill(x, 22, z, x, 25, z, BARS)
        put(x, 21, z, lantern(True))
for x in (11, 20, 29):
    for z in (14, 19, 25, 36, 42):
        put(x, 26, z, SHR)
# ceiling beams
for z in (16, 22, 28, 34, 40):
    for x in range(5, 36):
        put(x, 25, z, RNB if x % 2 else CHNB)
# chandelier above the arena
cx, cz = ARENA
fill(cx, 19, cz, cx, 25, cz, BARS)
for d in range(-2, 3):
    put(cx + d, 18, cz, FENCE); put(cx, 18, cz + d, FENCE)
for (dx, dz) in ((-2, 0), (2, 0), (0, -2), (0, 2)):
    put(cx + dx, 17, cz + dz, lantern(True))
put(cx, 17, cz, lantern(True, soul=True))

# --- lava troughs with fenced edges
for z in range(14, 41):
    for x in list(range(5, 9)) + list(range(32, 36)):
        put(x, 10, z, LAVA); put(x, 9, z, LAVA)
    put(9, 11, z, FENCE); put(31, 11, z, FENCE)
for z in range(14, 41, 6):
    put(9, 12, z, lantern(False)); put(31, 12, z, lantern(False))
# trough rim blocks at the ends
for x in list(range(5, 9)) + list(range(32, 36)):
    put(x, 10, 13, CHB); put(x, 10, 41, CHB)
    put(x, 9, 13, BS); put(x, 9, 41, BS)

# --- great pillars
def pillar(px, pz):
    fill(px - 1, 11, pz - 1, px + 1, 25, pz + 1, PBB)
    fill(px - 1, 11, pz - 1, px + 1, 11, pz + 1, CHB)
    fill(px - 1, 25, pz - 1, px + 1, 25, pz + 1, CHB)
    fill(px - 1, 24, pz - 1, px + 1, 24, pz + 1, RNB)
    fill(px - 1, 12, pz - 1, px + 1, 12, pz + 1, RNB)
    for y in (15, 20):
        for (dx, dz) in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            put(px + dx, y, pz + dz, SHR)
    for y in range(13, 24):
        for (dx, dz) in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
            put(px + dx, y, pz + dz, BS if y % 2 else PB)
for px in (11, 29):
    for pz in (16, 22, 38):
        pillar(px, pz)

# --- dais and throne
fill(14, 11, 40, 26, 11, 46, PB)
fill(15, 12, 42, 25, 12, 46, PBB)
fill(16, 13, 44, 24, 13, 46, PB)
for x in range(15, 26):
    put(x, 12, 41, stairs("polished_blackstone_brick", "north"))
for x in range(16, 25):
    put(x, 13, 43, stairs("polished_blackstone_brick", "north"))
# red runway up the steps
for z in (40, 41):
    for x in range(18, 23):
        put(x, 11, z, RNB)
for x in range(18, 23):
    put(x, 12, 42, RNB)
for z in (43, 44):
    for x in range(18, 23):
        put(x, 13, z, RNB)
# throne
put(20, 14, 45, stairs("blackstone", "north"))
put(19, 14, 45, slab("polished_blackstone_brick")); put(21, 14, 45, slab("polished_blackstone_brick"))
fill(18, 14, 46, 22, 20, 46, PBB)
fill(19, 21, 46, 21, 23, 46, PBB)
fill(20, 24, 46, 20, 25, 46, CHB)
put(17, 14, 46, PBB); put(23, 14, 46, PBB)
for y in range(15, 20):
    put(17, y, 46, CRY if y == 19 else PBB); put(23, y, 46, CRY if y == 19 else PBB)
put(16, 20, 46, CRY); put(24, 20, 46, CRY)
for y in (17, 19):
    put(20, y, 46, MAG)
put(20, 21, 46, SHR)
put(19, 22, 46, CRY); put(21, 22, 46, CRY)
put(18, 14, 46, GILD); put(22, 14, 46, GILD)
# brazier pairs beside the dais
for x in (13, 27):
    put(x, 11, 41, PBB); put(x, 12, 41, PBB); put(x, 13, 41, LAVA_CAULDRON)
    put(x, 11, 45, PBB); put(x, 12, 45, PBB); put(x, 13, 45, LAVA_CAULDRON)

# --- back wall sigil behind the throne
for x in range(13, 28):
    put(x, 12, 47, CRY); put(x, 24, 47, CRY)
for y in range(12, 25):
    put(13, y, 47, CRY); put(27, y, 47, CRY)
for x in range(14, 27):
    for y in range(13, 24):
        if (x + y) % 2 == 0 and not (18 <= x <= 22 and 14 <= y <= 25):
            put(x, y, 47, NB)
        elif not (18 <= x <= 22 and 14 <= y <= 25):
            put(x, y, 47, RNB)
for (x, y) in ((15, 18), (25, 18), (15, 22), (25, 22), (20, 23)):
    put(x, y, 47, SHR)

# --- doors from hall to the treasury (behind the pillars)
for dx0 in (10, 28):
    carve(dx0, 11, 47, dx0 + 2, 14, 48)
    carve(dx0 + 1, 15, 47, dx0 + 1, 15, 48)
    for x in range(dx0 - 1, dx0 + 4):
        put(x, 16, 47, CHB)
    put(dx0 - 1, 11, 47, CHB); put(dx0 + 3, 11, 47, CHB)
    for y in range(12, 16):
        put(dx0 - 1, y, 47, PBB); put(dx0 + 3, y, 47, PBB)
    put(dx0 + 1, 16, 47, GILD)

# --- windows (iron bars) in the long walls
for zc in (17, 24, 31, 38):
    for xs in ((3, 4), (36, 37)):
        for x in xs:
            for y in range(14, 21):
                for z in range(zc - 1, zc + 2):
                    put(x, y, z, BARS)
            put(x, 21, zc, BARS)
    # frame
    for xs in ((3, 4), (36, 37)):
        for x in xs:
            for z in (zc - 2, zc + 2):
                for y in range(13, 22):
                    put(x, y, z, CHB if y in (13, 21) else PBB)
            for z in range(zc - 1, zc + 2):
                put(x, 13, z, CHB)
            put(x, 22, zc, CHB)

# ================================================================== 6. treasury
# ceiling lights + hanging soul lanterns
for x in (10, 20, 30):
    for z in (51, 55):
        put(x, 19, z, SHR)
for x in (13, 27):
    for z in (52, 56):
        fill(x, 17, z, x, 18, z, BARS)
        put(x, 16, z, lantern(True, soul=True))
# wall trim
for x in range(5, 36):
    put(x, 12, 59, CRY if x % 2 else PBB)
    put(x, 18, 59, CHB)
for z in range(49, 59):
    put(5, 12, z, PBB); put(35, 12, z, PBB)
# central display plinth
fill(18, 10, 55, 22, 10, 58, GILD)
fill(19, 11, 56, 21, 11, 58, GILD)
put(20, 12, 57, LAVA_CAULDRON)
# chest alcoves
CHESTS = [9, 13, 17, 23, 27, 31]
for x in CHESTS:
    put(x, FL, 58, GILD)
    G[(x, 11, 58)] = "minecraft:chest[facing=north,type=single,waterlogged=false]"
    NBT[(x, 11, 58)] = {"id": "minecraft:chest", "LootTable": "elementalarsenal:chests/fire_hall"}
    put(x, 12, 58, AIR)
    put(x, 14, 58, lantern(True))  # lantern hangs from the lintel below
    put(x, 15, 58, CHB)
for x in CHESTS:
    put(x - 1, 11, 58, PBB) if (x - 1) not in CHESTS else None
    put(x + 1, 11, 58, PBB) if (x + 1) not in CHESTS else None

# ================================================================== 7. exterior
# buttresses along the long walls
for z in (14, 21, 28, 35, 42):
    for x in (2, 38):
        fill(x, 11, z, x, 25, z, PBB)
        put(x, 26, z, stairs("polished_blackstone_brick", "east" if x == 2 else "west", "bottom"))
        put(x, 20, z, CRY)
        put(x, 15, z, SHR)
# ledge parapets
for z in range(1, 62):
    put(1, 11, z, PBB_WALL) if z <= 8 or z >= 49 else None
    put(39, 11, z, PBB_WALL) if z <= 8 or z >= 49 else None
for x in range(1, 40):
    put(x, 11, 1, PBB_WALL)
    put(x, 11, 60, PBB_WALL)
for x in range(1, 40, 4):
    put(x, 12, 1, lantern(False))
for z in range(1, 9, 4):
    put(1, 12, z, lantern(False)); put(39, 12, z, lantern(False))
# forecourt braziers and runway lanterns
for (x, z) in ((16, 4), (24, 4), (16, 7), (24, 7)):
    put(x, 11, z, PBB); put(x, 12, z, LAVA_CAULDRON)
# roof ziggurat
roof_layers = [(3, 9, 37, 48, 27), (5, 11, 35, 46, 28), (8, 14, 32, 43, 29), (11, 17, 29, 40, 30), (14, 20, 26, 37, 31)]
for (x0, z0, x1, z1, y) in roof_layers:
    fill(x0, y, z0, x1, y, z1, ROOF_MAT)
    ring_rect(x0, z0, x1, z1, y, pick((NB, 50), (CHNB, 30), (CRY, 8), (RNB, 12)))
# roof spires
for (x, z) in ((3, 9), (37, 9), (3, 48), (37, 48), (3, 28), (37, 28)):
    fill(x, 28, z, x, 33, z, PBB_WALL)
    put(x, 34, z, CRY)
    put(x, 35, z, lantern(False))
# crown of the roof: a fire beacon
fill(19, 32, 27, 21, 32, 29, PBB)
put(20, 33, 28, LAVA_CAULDRON)
ring_rect(19, 27, 21, 29, 33, PBB_WALL)
put(20, 33, 28, LAVA_CAULDRON)
# rear treasury roof trim
for x in range(3, 38):
    put(x, 22, 60, CHB if x % 2 else PBB)
fill(3, 22, 47, 37, 22, 60, ROOF_MAT)

# ================================================================== 8. emblem + seal
ax, az = ARENA
for x in range(ax - 10, ax + 11):
    for z in range(az - 10, az + 11):
        dx, dz = x - ax, z - az
        r = math.hypot(dx, dz)
        ang = math.degrees(math.atan2(dz, dx)) % 90
        spoke = (min(abs(dx), abs(dz)) == 0) or abs(abs(dx) - abs(dz)) == 0
        b = None
        if abs(dx) <= 1 and abs(dz) <= 1:
            b = SEAL
        elif r <= 2.4:
            b = CRY if (x + z) % 2 == 0 else MAG
        elif r <= 3.5:
            b = CHB
        elif r <= 4.6:
            b = RNB
        elif r <= 8.4 and spoke and r > 4.6:
            b = NB if r < 7.5 else CRY
        elif r <= 5.7:
            b = PB
        elif r <= 6.8:
            b = CHNB if (x + z) % 2 == 0 else CRY
        elif r <= 7.8:
            b = RNB
        elif r <= 8.6:
            b = CHB
        if b:
            put(x, FL, z, b)
# glowing halo above the seal so it reads as an altar
put(ax, FL + 1, az, AIR)

# ================================================================== 9. connection shapes (walls / fences / bars)
def is_wall(b):
    return b.endswith("_wall")

SOLID = {PBB, CPBB, PB, BS, CHB, GILD, NB, RNB, CNB, CHNB, CRY, OBS, MAG, SHR, BASALT, PBASALT, SBASALT, SEAL}

def base(b):
    return b.split("[")[0]

def connects(x, y, z, kind):
    b = G.get((x, y, z))
    if b is None:
        return False
    n = base(b)
    if kind == "fence":
        return n == FENCE or n in SOLID
    if kind == "bars":
        return n == BARS or n in SOLID
    return n.endswith("_wall") or n in SOLID

DIRS = {"north": (0, -1), "south": (0, 1), "west": (-1, 0), "east": (1, 0)}
for (x, y, z), b in list(G.items()):
    n = base(b)
    if n == FENCE or n == BARS:
        kind = "fence" if n == FENCE else "bars"
        props = {d: ("true" if connects(x + dx, y, z + dz, kind) else "false") for d, (dx, dz) in DIRS.items()}
        props["waterlogged"] = "false"
        G[(x, y, z)] = n + "[" + ",".join(f"{k}={v}" for k, v in sorted(props.items())) + "]"
    elif is_wall(n):
        conn = {d: connects(x + dx, y, z + dz, "wall") for d, (dx, dz) in DIRS.items()}
        count = sum(conn.values())
        straight = count == 2 and ((conn["north"] and conn["south"]) or (conn["east"] and conn["west"]))
        above = G.get((x, y + 1, z))
        up = not straight or (above is not None and base(above) != AIR)
        props = {d: ("low" if v else "none") for d, v in conn.items()}
        props["up"] = "true" if up else "false"
        props["waterlogged"] = "false"
        G[(x, y, z)] = n + "[" + ",".join(f"{k}={v}" for k, v in sorted(props.items())) + "]"

# ================================================================== NBT writer
class Int(int): pass
class Str(str): pass
class Lst(list):
    def __init__(self, items, elem):
        super().__init__(items); self.elem = elem
TAG = {"end": 0, "int": 3, "string": 8, "list": 9, "compound": 10}

def w_name(s):
    b = s.encode("utf-8"); return struct.pack(">H", len(b)) + b

def kind(v):
    if isinstance(v, Int): return TAG["int"]
    if isinstance(v, Str): return TAG["string"]
    if isinstance(v, Lst): return TAG["list"]
    if isinstance(v, dict): return TAG["compound"]
    raise TypeError(type(v))

def payload(v):
    if isinstance(v, Int): return struct.pack(">i", int(v))
    if isinstance(v, Str): return w_name(str(v))
    if isinstance(v, Lst):
        out = struct.pack(">bi", v.elem, len(v))
        return out + b"".join(payload(i) for i in v)
    if isinstance(v, dict):
        out = b""
        for k, val in v.items():
            out += struct.pack(">b", kind(val)) + w_name(k) + payload(val)
        return out + b"\x00"
    raise TypeError(type(v))

def parse_state(s):
    if "[" not in s:
        return s, {}
    name, rest = s.split("[", 1)
    props = dict(p.split("=") for p in rest.rstrip("]").split(","))
    return name, props

palette, index = [], {}
blocks = []
for (x, y, z), b in sorted(G.items()):
    if b not in index:
        index[b] = len(palette)
        name, props = parse_state(b)
        entry = {"Name": Str(name)}
        if props:
            entry["Properties"] = {k: Str(v) for k, v in props.items()}
        palette.append(entry)
    e = {"pos": Lst([Int(x), Int(y), Int(z)], TAG["int"]), "state": Int(index[b])}
    if (x, y, z) in NBT:
        e["nbt"] = {k: Str(v) for k, v in NBT[(x, y, z)].items()}
    blocks.append(e)

root = {
    "DataVersion": Int(4671),
    "size": Lst([Int(W), Int(H), Int(D)], TAG["int"]),
    "palette": Lst(palette, TAG["compound"]),
    "blocks": Lst(blocks, TAG["compound"]),
    "entities": Lst([], TAG["compound"]),
}
data = struct.pack(">b", TAG["compound"]) + w_name("") + payload(root)
with gzip.GzipFile(OUT, "wb", mtime=0) as f:
    f.write(data)
print("blocks:", len(blocks), "palette:", len(palette), "chests:", len(NBT), "seal:",
      sum(1 for b in G.values() if b == SEAL))

# ================================================================== preview (isometric)
if PREVIEW:
    from PIL import Image, ImageDraw
    COL = {
        "polished_blackstone_bricks": (44, 40, 54), "cracked_polished_blackstone_bricks": (40, 36, 50),
        "polished_blackstone": (52, 47, 60), "blackstone": (34, 30, 38), "chiseled_polished_blackstone": (60, 54, 72),
        "gilded_blackstone": (150, 120, 50), "nether_bricks": (60, 30, 36), "red_nether_bricks": (110, 22, 26),
        "cracked_nether_bricks": (54, 28, 32), "chiseled_nether_bricks": (70, 34, 40), "crying_obsidian": (90, 30, 150),
        "obsidian": (20, 14, 30), "magma_block": (200, 90, 20), "shroomlight": (250, 160, 70),
        "basalt": (60, 62, 68), "polished_basalt": (70, 72, 78), "smooth_basalt": (50, 52, 58),
        "lava": (255, 110, 20), "iron_bars": (120, 120, 130), "nether_brick_fence": (70, 34, 40),
        "lava_cauldron": (255, 140, 30), "lantern": (255, 200, 90), "soul_lantern": (90, 200, 230),
        "inferno_seal": (255, 200, 60), "chest": (160, 110, 50),
    }
    def color(b):
        n = base(b).split(":")[1]
        if n.endswith("_stairs") or n.endswith("_slab") or n.endswith("_wall"):
            n = n.rsplit("_", 1)[0]
        return COL.get(n, (120, 120, 120))
    def render(path, keep, s=5):
        im = Image.new("RGB", (int((W + D) * s * 0.87) + 40, int((W + D) * s * 0.5 + H * s) + 40), (16, 10, 14))
        dr = ImageDraw.Draw(im)
        ox, oy = D * s * 0.87 + 20, H * s + 20
        order = sorted((p for p in G if G[p] != AIR and keep(p)), key=lambda p: (p[0] + p[2], p[1]))
        occ = set(order)
        def sc(x, y, z):
            return (ox + (x - z) * s * 0.87, oy + (x + z) * s * 0.5 - y * s)
        for (x, y, z) in order:
            if (x + 1, y, z) in occ and (x, y + 1, z) in occ and (x, y, z + 1) in occ:
                continue
            c = color(G[(x, y, z)])
            top = [sc(x, y + 1, z), sc(x + 1, y + 1, z), sc(x + 1, y + 1, z + 1), sc(x, y + 1, z + 1)]
            left = [sc(x, y + 1, z + 1), sc(x + 1, y + 1, z + 1), sc(x + 1, y, z + 1), sc(x, y, z + 1)]
            right = [sc(x + 1, y + 1, z), sc(x + 1, y + 1, z + 1), sc(x + 1, y, z + 1), sc(x + 1, y, z)]
            dr.polygon(top, fill=tuple(min(255, int(v * 1.25)) for v in c))
            dr.polygon(left, fill=tuple(int(v * 0.8) for v in c))
            dr.polygon(right, fill=tuple(int(v * 0.6) for v in c))
        im.save(path)
    render(PREVIEW + "_outside.png", lambda p: True)
    render(PREVIEW + "_cutaway.png", lambda p: not (p[0] > 20 and p[1] > 10) and not (p[2] < 9))
